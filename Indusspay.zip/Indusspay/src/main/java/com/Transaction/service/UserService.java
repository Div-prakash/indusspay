package com.Transaction.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Transaction.model.User;
import com.Transaction.repository.BankRepository;
import com.Transaction.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BankRepository bankRepository;

    public User addUser(User user) {
        // Business logic for adding a user, including validation
    	
    	return null;
    }

    public List<User> getUsersByIds(List<Long> userIds) {
        // Fetch users by a list of IDs or all users if list is empty
    	List<User> test = null;
    	return test;
    }

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public BankRepository getBankRepository() {
		return bankRepository;
	}

	public void setBankRepository(BankRepository bankRepository) {
		this.bankRepository = bankRepository;
	}
}
