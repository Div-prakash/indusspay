package com.Transaction.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.Transaction.model.Txn;
import com.Transaction.model.User;
import com.Transaction.model.UserTransactionDetails;
import com.Transaction.model.Bank;
import com.Transaction.repository.TxnRepository;
import com.Transaction.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class TxnService {

    @Autowired
    private TxnRepository txnRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Adds a transaction for a user, ensuring proper validation and random transaction ID generation.
     * 
     * @param userId The ID of the user associated with the transaction.
     * @param txn The transaction object to be added.
     * @return The saved transaction.
     */
    public Txn addTxn(Long id, Txn txn) {
        // Fetch the user, throw an exception if not found
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found with userId: " + id));

        // Validate the transaction amount
        if (txn.getAmount() <= 0) {
            throw new IllegalArgumentException("Transaction amount must be greater than zero.");
        }

        // Generate a random txnId
        String txnId = generateRandomTxnId();
        txn.setTxnId(txnId);

        // Set the user to the transaction
        txn.setUser(user);

        // Save the transaction to the database
        return txnRepository.save(txn);
    }
    
    
    public List<UserTransactionDetails> getTxnDetails(List<Long> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            // Fetch all users and their transactions
            return userRepository.findAll()
                    .stream()
                    .map(user -> mapToUserTransactionDetails(user))
                    .collect(Collectors.toList());
        } else {
            // Fetch transactions for the specified users
            return userIds.stream()
                    .map(id -> {
                        User user = userRepository.findById(id)
                                .orElseThrow(() -> new EntityNotFoundException("User not found with userId: " + id));
                        return mapToUserTransactionDetails(user);
                    })
                    .collect(Collectors.toList());
        }
    }
    
    

    /**
     * Generates a random 8-digit transaction ID.
     * 
     * @return A random 8-digit transaction ID as a string.
     */
    private String generateRandomTxnId() {
        return String.valueOf((int) (Math.random() * 100000000)); // Generates an 8-digit txnId
    }

    /**
     * Fetches all transactions for a user within a specified amount range.
     * If no transactions are found, it throws an exception.
     * 
     * @param userId The ID of the user.
     * @param initialRange The initial amount range.
     * @param finalRange The final amount range.
     * @return A UserTransactionDetails object containing user, bank, and transaction details.
     */
    public UserTransactionDetails getTxnsInRange(Long userId, double initialRange, double finalRange) {
        // Fetch the transactions in the specified amount range
        List<Txn> txnsInRange = txnRepository.findByUserIdAndAmountBetween(userId, initialRange, finalRange);

        if (txnsInRange.isEmpty()) {
            throw new EntityNotFoundException("No transactions found in the specified range for userId: " + userId);
        }

        // Fetch the user and bank details
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with userId: " + userId));
        
        // Assuming the user has a bank associated
        Bank bank = user.getBank();
        
        return new UserTransactionDetails(user, bank, txnsInRange);
    }
    
    private UserTransactionDetails mapToUserTransactionDetails(User user) {
        // Get the user's bank details
        Bank bank = user.getBank();

        // Get the user's transactions
        List<Txn> transactions = txnRepository.findByUserId(user.getId());

        // Return the user transaction details
        return new UserTransactionDetails(user, bank, transactions);
    }

    /**
     * Fetches all transactions sorted by the amount in ascending order.
     * 
     * @return A list of sorted transactions.
     */
    public List<Txn> getAllSortedByAmount() {
        // Get all transactions sorted by amount in ascending order
        return txnRepository.findAll(Sort.by(Sort.Direction.ASC, "amount"));
    }
}
