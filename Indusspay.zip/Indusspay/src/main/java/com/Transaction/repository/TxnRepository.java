package com.Transaction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Transaction.model.Txn;

public interface TxnRepository extends JpaRepository<Txn, Long> {
    List<Txn> findByUserIdAndAmountBetween(Long id, double initialRange, double finalRange);
    List<Txn> findAllByOrderByAmountAsc();
    List<Txn> findByUserId(Long userId);
}
