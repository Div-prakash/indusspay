package com.Transaction.model;

import java.util.List;

public class UserTransactionDetails {
    
    private User user;
    private Bank bank;
    private List<Txn> transactions;

    public UserTransactionDetails(User user, Bank bank, List<Txn> transactions) {
        this.user = user;
        this.bank = bank;
        this.transactions = transactions;
    }

    // Getters and Setters
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public List<Txn> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Txn> transactions) {
        this.transactions = transactions;
    }
}
