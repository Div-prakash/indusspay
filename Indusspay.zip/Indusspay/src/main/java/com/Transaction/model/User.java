package com.Transaction.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_tbl")
public class User {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    public Long getId() {
	    	return id;
	    }
	    
	    private String firstName;
	    private String lastName;
	    private String email;
	    private String phone;

	    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
	    private Bank bank;
	    
	    public Bank getBank() {
	    	return bank;
	    }

	    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	    private List<Txn> txns = new ArrayList<>();
	    public List<Txn> getTxns() {
	    	return txns;
	    }

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}

	    // Getters and setters
	}


