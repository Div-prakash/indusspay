package com.Transaction.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_bank_tbl")
public class Bank {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    private String bankName;
	    private String bankIfsc;
	    private String accountNumber;

	    @OneToOne
	    @JoinColumn(name = "user_id")
	    private User user;

		public String getBankIfsc() {
			return bankIfsc;
		}

		public void setBankIfsc(String bankIfsc) {
			this.bankIfsc = bankIfsc;
		}

		public String getBankName() {
			return bankName;
		}

		public void setBankName(String bankName) {
			this.bankName = bankName;
		}

		public String getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}

	    // Getters and setters
	}


