package com.Transaction.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Transaction.model.Txn;
import com.Transaction.model.User;
import com.Transaction.model.UserTransactionDetails;
import com.Transaction.service.TxnService;

@RestController
@RequestMapping("/txn")
public class TxnController {

    @Autowired
    private TxnService txnService;

    @PostMapping("/add/{id}")
    public ResponseEntity<String> addTxn(@PathVariable Long userId, @RequestBody Txn txn) {
    	try {
            txnService.addTxn(userId, txn);
            return new ResponseEntity<>("Transaction added successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred while adding the transaction.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/get/details")
    public ResponseEntity<List<User>> getTxnDetails(@RequestBody List<Long> userIds) {
    	try {

            List<UserTransactionDetails> txnDetails = txnService.getTxnDetails(userIds);
            List<User> allUsers = new ArrayList<User>();
            txnDetails.forEach((user) -> {
            	allUsers.add(user.getUser());
            });
            return new ResponseEntity<>(allUsers, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/amount/{initial_range}/{final_range}")
    public ResponseEntity<?> getTxnsByAmountRange(@RequestParam Long userId, 
                                                  @PathVariable double initial_range, 
                                                  @PathVariable double final_range) {
    	try {
            return new ResponseEntity<>(txnService.getTxnsInRange(userId, initial_range, final_range), HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("Error fetching transactions in range.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/sort/amount")
    public ResponseEntity<List<Txn>> sortTxnsByAmount() {
    	try {
            return new ResponseEntity<>(txnService.getAllSortedByAmount(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
